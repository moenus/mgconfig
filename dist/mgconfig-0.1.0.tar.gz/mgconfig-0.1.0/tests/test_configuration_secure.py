# Copyright (c) 2025 moenus
# SPDX-License-Identifier: MIT

import os
from t_helpers import prepare_clean_basedir, create_configuration, prepare_new_env_master_key

CONFIG_ID = 'tst_secret'

BASE_DIRECTORY_PATH = prepare_clean_basedir()


def test_configuration_secrets():
    prepare_new_env_master_key()
    config = create_configuration()

    assert config.save_new_value(CONFIG_ID,'passwort_1')
    assert config.get_config_value(CONFIG_ID)._value_new == 'passwort_1' 

    new_masterkey = config.get_new_masterkey()
    os.environ["APP_KEY"] = new_masterkey

    config = create_configuration()     # read in a second time after changing masterkey

    assert config._config_values[CONFIG_ID].value == 'passwort_1'
     
    config.save_new_value(CONFIG_ID,'passwort_2',apply_immediately=True)
    assert config._config_values[CONFIG_ID].value == 'passwort_2' 

    config = create_configuration()     # read in a second time after changing masterkey

    assert config._config_values[CONFIG_ID].value == 'passwort_2'
    

if __name__ == '__main__':
    test_configuration_secrets()
    print('finished successfully')